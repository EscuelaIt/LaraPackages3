
                <div class="container-fluid container-fixed-lg">
                  <ul class="nav nav-tabs nav-tabs-simple" role="tablist">
                  @foreach($locales as $idx => $locale)
                    <li class="{{($idx == 0) ? 'active':''}}">
                      <a href="#lang-{{$locale->language}}" data-toggle="tab" role="tab">{{$locale->language}}</a>
                    </li>
                  @endforeach
                  </ul>
                  
                  <div class="panel-body">
                  <form id="form-personal" role="form" id="postForm" method="post" enctype="multipart/form-data" action="{{$formAction}}" autocomplete="off">
                    <div class="tab-content">
                      @foreach ($locales as $idx => $locale)
                        <div class="tab-pane {{ ($idx == 0) ? 'active' : ''}}" id="lang-{{$locale->language}}">
                            <div class="row">
                                <div class="col-sm-12">
                                  <div class="form-group form-group-default">
                                    <label>Titulo</label>
                                    <input type="text" class="form-control" name="title_{{$locale->language}}" value="{{{ $articles->translate($locale->language)->title }}}">    
                                  </div>
                                </div>
                              </div>
                          <div class="row">
                                <div class="col-sm-12">
                                  <div class="form-group">
                                    <label>Contenido</label>
                                    <div class="summernote-wrapper">
                                      <textarea  class="summernote"  name="content_{{$locale->language}}" rows="18"> {{{ $articles->translate($locale->language)->content }}}</textarea>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <script>
                              /* Custom javascript summernote */
                              var postForm = function() {
                                var content = $('textarea[name="content_{{$locale->language}}"]').html($('#summernote').code());
                              }
                            </script>

                      @endforeach
                  </div>

                  <div class="row">
                    <div class="col-sm-12">
                    <div class="form-group form-group-default">
                  	<label>Thumbnail</label>
                      @if (strlen($articles->thumbnail) > 2)
                      <div class="col-sm-2"><img src="{{asset(Config::get('app.uploads').$articles->thumbnail)}}" class="img-responsive thumbnail"></div><br>
                      @endif
                      <input type="file" class="form-control" name="thumbnail" value="{{ $articles->thumbnail }}">
                    </div>
                  </div>
                  </div>
                  
                    <input type="hidden" name="_token" value="{{csrf_token()}}">

                    <div class="col-sm-12 no-padding">
                      <button type="submit" class="btn btn-success">Enviar</button>
                    </div>
                  </form>
                  </div>
  
                </div>
          