<?php

	public function saveData($id = null) {
		$articles = ($id) ? Article::find($id) : new Article;
		$locales = DB::table('locales')->get();

		foreach ($locales as $locale) {
			App::setLocale($locale->language);
			$articles->title  = Request::input('title_'.$locale->language);
			$articles->content  = Request::input('content_'.$locale->language);
			$articles->slug = str_slug(Request::input('title_'.$locale->language),'-');
			$articles->save();
		}
			$thumbnail = Functions::uploadFile('thumbnail');
			if ($thumbnail) {
			    Functions::deleteFile($articles->thumbnail);
				$articles->thumbnail = $thumbnail;
			}
			$articles->save();

	}

}